import supabase from './db-client.js';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(204).end();

  try {
    const { period, startDate, endDate } = req.query;
    let dateFilter = {};

    if (startDate && endDate) {
      dateFilter = { gte: startDate, lte: endDate };
    } else if (period) {
      const now = new Date();
      let start, end;

      if (period === 'today') {
        start = new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString().split('T')[0];
        end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).toISOString().split('T')[0];
      } else if (period === 'week') {
        const dayOfWeek = now.getDay();
        const diff = now.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
        start = new Date(now.getFullYear(), now.getMonth(), diff).toISOString().split('T')[0];
        end = new Date(start.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0].split('T')[0];
        // Fix: calculate end properly
        const endDateObj = new Date(now.getFullYear(), now.getMonth(), diff + 7);
        end = endDateObj.toISOString().split('T')[0];
      } else if (period === 'month') {
        start = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().split('T')[0];
        end = new Date(now.getFullYear(), now.getMonth() + 1, 1).toISOString().split('T')[0];
      } else if (period === 'year') {
        start = new Date(now.getFullYear(), 0, 1).toISOString().split('T')[0];
        end = new Date(now.getFullYear() + 1, 0, 1).toISOString().split('T')[0];
      }

      if (start && end) {
        dateFilter = { gte: start, lte: end };
      }
    }

    let query = supabase.from('expenses').select('amount, category');
    
    if (dateFilter.gte && dateFilter.lte) {
      query = query.gte('date', dateFilter.gte).lte('date', dateFilter.lte);
    }

    const { data, error } = await query;
    if (error) throw error;

    // Calculate totals
    const total = data.reduce((sum, exp) => sum + parseFloat(exp.amount), 0);
    
    // Group by category
    const categoryTotals = data.reduce((acc, exp) => {
      const cat = exp.category || 'Other';
      acc[cat] = (acc[cat] || 0) + parseFloat(exp.amount);
      return acc;
    }, {});

    // Calculate daily totals for chart
    const dailyTotals = data.reduce((acc, exp) => {
      const day = exp.date;
      acc[day] = (acc[day] || 0) + parseFloat(exp.amount);
      return acc;
    }, {});

    return res.status(200).json({
      total,
      count: data.length,
      categoryBreakdown: Object.entries(categoryTotals).map(([category, amount]) => ({
        category,
        amount,
        percentage: total > 0 ? ((amount / total) * 100).toFixed(1) : 0
      })).sort((a, b) => b.amount - a.amount),
      dailyTotals: Object.entries(dailyTotals)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([date, amount]) => ({ date, amount }))
    });
  } catch (err) {
    console.error('Summary API error:', err);
    res.status(500).json({ error: err.message });
  }
}
