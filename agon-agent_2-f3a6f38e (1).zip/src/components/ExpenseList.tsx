import { motion } from 'framer-motion';
import { Edit2, Trash2, Calendar } from 'lucide-react';
import { categories } from '../App';

interface ExpenseListProps {
  expenses: any[];
  loading: boolean;
  onEdit: (expense: any) => void;
  onDelete: (id: number) => void;
}

export default function ExpenseList({ expenses, loading, onEdit, onDelete }: ExpenseListProps) {
  const getCategoryInfo = (name: string) => {
    return categories.find(c => c.name === name) || categories[categories.length - 1];
  };

  const formatCurrency = (amount: number) => {
    const safeAmount = typeof amount === 'number' && !isNaN(amount) ? amount : 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(safeAmount);
  };

  // Ensure expenses is always an array
  const safeExpenses = Array.isArray(expenses) ? expenses : [];

  if (loading) {
    return (
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/10 p-8">
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="animate-pulse flex items-center gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-xl" />
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-white/10 rounded w-1/3" />
                <div className="h-3 bg-white/10 rounded w-1/2" />
              </div>
              <div className="h-6 bg-white/10 rounded w-20" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (safeExpenses.length === 0) {
    return (
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/10 p-12 text-center">
        <div className="w-16 h-16 mx-auto mb-4 bg-white/10 rounded-full flex items-center justify-center">
          <Calendar className="w-8 h-8 text-slate-400" />
        </div>
        <h3 className="text-lg font-semibold text-white mb-2">No expenses found</h3>
        <p className="text-slate-400">Start tracking your expenses by adding a new one!</p>
      </div>
    );
  }

  return (
    <div className="bg-white/10 backdrop-blur-xl rounded-2xl border border-white/10 overflow-hidden">
      <div className="px-6 py-4 border-b border-white/10">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <Calendar className="w-5 h-5 text-violet-400" />
          Recent Expenses
          <span className="text-sm font-normal text-slate-400">({safeExpenses.length})</span>
        </h2>
      </div>
      
      <div className="divide-y divide-white/5">
        {safeExpenses.map((expense, index) => {
          // Safety: skip invalid entries
          if (!expense || typeof expense !== 'object') return null;
          
          const cat = getCategoryInfo(expense.category || '');
          const IconComponent = cat.icon;
          const safeId = expense.id;
          const safeAmount = typeof expense.amount === 'number' ? expense.amount : 0;
          const safeDate = expense.date || '';
          const safeDescription = expense.description || expense.category || 'Expense';
          const safeCategoryName = expense.category || 'Other';
          
          return (
            <motion.div
              key={safeId || `exp-${index}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center gap-4 px-6 py-4 hover:bg-white/5 transition-colors group"
            >
              {/* Category Icon */}
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                style={{ backgroundColor: `${cat.color}20` }}
              >
                <IconComponent className="w-6 h-6" style={{ color: cat.color }} />
              </div>
              
              {/* Details */}
              <div className="flex-1 min-w-0">
                <p className="font-medium text-white truncate">
                  {safeDescription}
                </p>
                <div className="flex items-center gap-2 mt-1">
                  <span 
                    className="text-xs px-2 py-0.5 rounded-full font-medium"
                    style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                  >
                    {safeCategoryName}
                  </span>
                  <span className="text-xs text-slate-400">
                    {safeDate ? new Date(safeDate).toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric',
                      year: 'numeric'
                    }) : 'Unknown date'}
                  </span>
                </div>
              </div>
              
              {/* Amount */}
              <span className="font-semibold text-white text-lg shrink-0">
                -{formatCurrency(safeAmount)}
              </span>
              
              {/* Actions */}
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  onClick={() => onEdit(expense)}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  aria-label="Edit expense"
                >
                  <Edit2 className="w-4 h-4 text-slate-400 hover:text-violet-400" />
                </button>
                <button
                  onClick={() => onDelete(safeId)}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                  aria-label="Delete expense"
                >
                  <Trash2 className="w-4 h-4 text-slate-400 hover:text-red-400" />
                </button>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}