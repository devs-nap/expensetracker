import { motion } from 'framer-motion';
import { PieChart } from 'lucide-react';
import { categories } from '../App';

interface CategoryChartProps {
  summary: any;
}

export default function CategoryChart({ summary }: CategoryChartProps) {
  const getCategoryInfo = (name: string) => {
    return categories.find(c => c.name === name) || categories[categories.length - 1];
  };

  const formatCurrency = (amount: number) => {
    const safeAmount = typeof amount === 'number' && !isNaN(amount) ? amount : 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(safeAmount);
  };

  // Safe access with defaults
  const categoryBreakdown = Array.isArray(summary?.categoryBreakdown)
    ? summary.categoryBreakdown
    : [];

  if (categoryBreakdown.length === 0) {
    return (
      <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
        <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
          <PieChart className="w-5 h-5 text-violet-400" />
          Spending by Category
        </h3>
        <p className="text-slate-400 text-center py-8">No data available</p>
      </div>
    );
  }

  return (
    <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
      <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
        <PieChart className="w-5 h-5 text-violet-400" />
        Spending by Category
      </h3>
      
      <div className="space-y-4">
        {categoryBreakdown.map((cat: any, index: number) => {
          // Safety: skip invalid entries
          if (!cat || typeof cat !== 'object') return null;
          
          const catInfo = getCategoryInfo(cat.category || '');
          const IconComponent = catInfo.icon;
          const safeAmount = typeof cat.amount === 'number' ? cat.amount : 0;
          const safePercentage = typeof cat.percentage === 'number' ? cat.percentage : 0;
          
          return (
            <motion.div
              key={cat.category || `cat-${index}`}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="group"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <div 
                    className="w-9 h-9 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${catInfo.color}20` }}
                  >
                    <IconComponent className="w-[18px] h-[18px]" style={{ color: catInfo.color }} />
                  </div>
                  <span className="font-medium text-white">{cat.category || 'Uncategorized'}</span>
                </div>
                <div className="text-right">
                  <span className="font-semibold text-white">{formatCurrency(safeAmount)}</span>
                  <span className="text-sm text-slate-400 ml-2">({safePercentage.toFixed(1)}%)</span>
                </div>
              </div>
              
              {/* Progress Bar */}
              <div className="h-2.5 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min(Math.max(safePercentage, 0), 100)}%` }}
                  transition={{ delay: index * 0.05 + 0.2, duration: 0.5, ease: 'easeOut' }}
                  className="h-full rounded-full"
                  style={{ 
                    background: `linear-gradient(90deg, ${catInfo.color}, ${catInfo.color}99)` 
                  }}
                />
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}