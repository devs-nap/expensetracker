import { motion } from 'framer-motion';
import { Wallet, Receipt, TrendingUp, CalendarDays } from 'lucide-react';
import type { Period } from '../App';

interface SummaryCardsProps {
  summary: any;
  period: Period;
}

export default function SummaryCards({ summary, period }: SummaryCardsProps) {
  const formatCurrency = (amount: number) => {
    const safeAmount = typeof amount === 'number' && !isNaN(amount) ? amount : 0;
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(safeAmount);
  };

  const getPeriodLabel = () => {
    switch (period) {
      case 'today': return "Today's";
      case 'week': return "This Week's";
      case 'month': return "This Month's";
      case 'year': return "This Year's";
      case 'all': return "All Time";
      default: return '';
    }
  };

  // Safe access to summary data with defaults
  const total = typeof summary?.total === 'number' ? summary.total : 0;
  const count = typeof summary?.count === 'number' ? summary.count : 0;
  const avgPerTx = count > 0 ? total / count : 0;
  const topCategory = Array.isArray(summary?.categoryBreakdown) && summary.categoryBreakdown.length > 0
    ? summary.categoryBreakdown[0].category
    : 'N/A';
  const topCategoryAmount = Array.isArray(summary?.categoryBreakdown) && summary.categoryBreakdown.length > 0
    ? summary.categoryBreakdown[0].amount
    : null;

  const cards = [
    {
      title: `${getPeriodLabel()} Spending`,
      value: formatCurrency(total),
      icon: Wallet,
      color: 'from-violet-500 to-fuchsia-500',
      bgColor: 'bg-violet-500/10',
      textColor: 'text-violet-400',
    },
    {
      title: 'Total Transactions',
      value: String(count),
      icon: Receipt,
      color: 'from-cyan-500 to-blue-500',
      bgColor: 'bg-cyan-500/10',
      textColor: 'text-cyan-400',
    },
    {
      title: 'Average per Transaction',
      value: formatCurrency(avgPerTx),
      icon: TrendingUp,
      color: 'from-emerald-500 to-teal-500',
      bgColor: 'bg-emerald-500/10',
      textColor: 'text-emerald-400',
    },
    {
      title: 'Top Category',
      value: topCategory,
      icon: CalendarDays,
      color: 'from-orange-500 to-amber-500',
      bgColor: 'bg-orange-500/10',
      textColor: 'text-orange-400',
      subValue: topCategoryAmount != null ? formatCurrency(topCategoryAmount) : null,
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {cards.map((card, index) => {
        const IconComponent = card.icon;
        return (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white/10 backdrop-blur-xl rounded-2xl p-5 border border-white/10 hover:border-white/20 transition-all group"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-slate-400 mb-1">{card.title}</p>
                <p className="text-2xl font-bold text-white">{card.value}</p>
                {card.subValue && (
                  <p className={`text-sm mt-1 ${card.textColor}`}>{card.subValue}</p>
                )}
              </div>
              <div className={`p-3 ${card.bgColor} rounded-xl group-hover:scale-110 transition-transform`}>
                <IconComponent className={`w-6 h-6 ${card.textColor}`} />
              </div>
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}