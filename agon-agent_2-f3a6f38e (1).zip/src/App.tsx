import { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, X, Calendar, ShoppingCart, Utensils, Car, Home, HeartPulse,
  Gamepad2, BookOpen, Plane, MoreHorizontal, ChevronDown,
  PieChart, BarChart3, Wallet, RefreshCw, AlertCircle
} from 'lucide-react';
import ExpenseForm from './components/ExpenseForm';
import ExpenseList from './components/ExpenseList';
import SummaryCards from './components/SummaryCards';
import CategoryChart from './components/CategoryChart';
import ErrorBoundary from './components/ErrorBoundary';

export type Period = 'today' | 'week' | 'month' | 'year' | 'all';

const categories = [
  { name: 'Food & Dining', icon: Utensils, color: '#FF6B6B' },
  { name: 'Shopping', icon: ShoppingCart, color: '#4ECDC4' },
  { name: 'Transport', icon: Car, color: '#45B7D1' },
  { name: 'Housing', icon: Home, color: '#96CEB4' },
  { name: 'Healthcare', icon: HeartPulse, color: '#FFEAA7' },
  { name: 'Entertainment', icon: Gamepad2, color: '#DDA0DD' },
  { name: 'Education', icon: BookOpen, color: '#98D8C8' },
  { name: 'Travel', icon: Plane, color: '#F7DC6F' },
  { name: 'Bills & Utilities', icon: Home, color: '#BB8FCE' },
  { name: 'Other', icon: MoreHorizontal, color: '#AEB6BF' },
];

export { categories };

function App() {
  const [expenses, setExpenses] = useState<any[]>([]);
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activePeriod, setActivePeriod] = useState<Period>('month');
  const [showForm, setShowForm] = useState(false);
  const [editingExpense, setEditingExpense] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const mountedRef = useRef(true);

  // Cleanup on unmount
  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const fetchData = useCallback(async (period?: Period) => {
    const targetPeriod = period || activePeriod;
    setLoading(true);
    setError(null);
    
    try {
      const [expensesRes, summaryRes] = await Promise.all([
        fetch(`/api/expenses?period=${targetPeriod}`),
        fetch(`/api/expenses-summary?period=${targetPeriod}`)
      ]);
      
      // Check for HTTP errors
      if (!expensesRes.ok || !summaryRes.ok) {
        throw new Error(`Server error: ${!expensesRes.ok ? expensesRes.status : summaryRes.status}`);
      }
      
      let expensesData: any[];
      let summaryData: any;
      
      try {
        expensesData = await expensesRes.json();
        summaryData = await summaryRes.json();
      } catch (parseErr) {
        throw new Error('Failed to parse server response');
      }
      
      // Validate data before setting state
      if (!Array.isArray(expensesData)) {
        console.warn('Expenses data is not an array, using empty array');
        expensesData = [];
      }
      
      if (!summaryData || typeof summaryData !== 'object') {
        console.warn('Summary data is invalid, using default');
        summaryData = { total: 0, count: 0, categoryBreakdown: [], dailyTotals: [] };
      }
      
      // Only update state if component is still mounted
      if (mountedRef.current) {
        setExpenses(expensesData || []);
        setSummary(summaryData || { total: 0, count: 0, categoryBreakdown: [], dailyTotals: [] });
        setError(null);
      }
    } catch (err: any) {
      console.error('Fetch error:', err);
      if (mountedRef.current) {
        setError(err.message || 'Failed to load data');
        // Keep existing data visible even on error
      }
    } finally {
      if (mountedRef.current) {
        setLoading(false);
      }
    }
  }, [activePeriod]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleAddExpense = async (expense: any) => {
    setError(null);
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expense),
      });
      
      if (!res.ok) {
        const errData = await res.json().catch(() => ({ error: 'Failed to add expense' }));
        throw new Error(errData.error || `Failed to add expense (${res.status})`);
      }
      
      setShowForm(false);
      fetchData();
    } catch (err: any) {
      setError(err.message || 'Failed to add expense');
    }
  };

  const handleUpdateExpense = async (expense: any) => {
    setError(null);
    try {
      const res = await fetch('/api/expenses', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...expense, id: editingExpense.id }),
      });
      
      if (!res.ok) {
        const errData = await res.json().catch(() => ({ error: 'Failed to update expense' }));
        throw new Error(errData.error || `Failed to update expense (${res.status})`);
      }
      
      setEditingExpense(null);
      setShowForm(false);
      fetchData();
    } catch (err: any) {
      setError(err.message || 'Failed to update expense');
    }
  };

  const handleDeleteExpense = async (id: number) => {
    if (!confirm('Are you sure you want to delete this expense?')) return;
    setError(null);
    try {
      const res = await fetch('/api/expenses', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      
      if (!res.ok) {
        throw new Error(`Failed to delete expense (${res.status})`);
      }
      
      fetchData();
    } catch (err: any) {
      setError(err.message || 'Failed to delete expense');
    }
  };

  const periods: { key: Period; label: string }[] = [
    { key: 'today', label: 'Today' },
    { key: 'week', label: 'This Week' },
    { key: 'month', label: 'This Month' },
    { key: 'year', label: 'This Year' },
    { key: 'all', label: 'All Time' },
  ];

  return (
    <ErrorBoundary>
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-xl bg-slate-900/70 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-3"
            >
              <div className="p-2 bg-gradient-to-br from-violet-500 to-fuchsia-500 rounded-xl">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">ExpenseTracker</h1>
                <p className="text-xs text-slate-400">Track your spending wisely</p>
              </div>
            </motion.div>
            
            <div className="flex items-center gap-3">
              {/* Retry button */}
              {error && (
                <motion.button
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => fetchData()}
                  className="flex items-center gap-2 px-4 py-2.5 bg-orange-500/20 text-orange-400 rounded-xl font-medium border border-orange-500/30 hover:bg-orange-500/30 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span className="hidden sm:inline">Retry</span>
                </motion.button>
              )}
              
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => { setEditingExpense(null); setShowForm(true); setError(null); }}
                className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white rounded-xl font-medium shadow-lg shadow-violet-500/25 hover:shadow-violet-500/40 transition-shadow"
              >
                <Plus className="w-5 h-5" />
                <span className="hidden sm:inline">Add Expense</span>
              </motion.button>
            </div>
          </div>
        </div>
      </header>

      {/* Error Banner */}
      <AnimatePresence>
        {error && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-red-500/10 border-b border-red-500/20"
          >
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
              <div className="flex items-center gap-3 text-red-400">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span className="text-sm font-medium">{error}</span>
              </div>
              <button
                onClick={() => setError(null)}
                className="text-red-400 hover:text-red-300 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Period Selector */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-wrap gap-2 mb-8"
        >
          {periods.map((period) => (
            <button
              key={period.key}
              onClick={() => setActivePeriod(period.key)}
              className={`px-5 py-2.5 rounded-xl font-medium transition-all duration-200 ${
                activePeriod === period.key
                  ? 'bg-gradient-to-r from-violet-500 to-fuchsia-500 text-white shadow-lg shadow-violet-500/25'
                  : 'bg-white/10 text-slate-300 hover:bg-white/15 border border-white/10'
              }`}
            >
              {period.label}
            </button>
          ))}
        </motion.div>

        {/* Summary Cards - with safety checks */}
        {!loading && summary && (
          <SummaryCards summary={summary} period={activePeriod} />
        )}

        {/* Charts Section - with safety checks */}
        {!loading && summary && summary.categoryBreakdown && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8"
          >
            <CategoryChart summary={summary} />
            
            {/* Daily Trend Mini Chart */}
            <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-violet-400" />
                Spending Trend
              </h3>
              {summary.dailyTotals && Array.isArray(summary.dailyTotals) && summary.dailyTotals.length > 0 ? (
                <div className="space-y-3">
                  {summary.dailyTotals.slice(-7).map((day: any, idx: number) => {
                    const maxAmount = Math.max(...summary.dailyTotals.map((d: any) => d.amount || 0), 1);
                    const safeAmount = day.amount || 0;
                    const percentage = Math.min((safeAmount / maxAmount) * 100, 100);
                    
                    return (
                      <div key={`day-${day.date || idx}`} className="flex items-center gap-3">
                        <span className="text-sm text-slate-400 w-24 shrink-0">
                          {day.date ? new Date(day.date).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }) : 'Unknown'}
                        </span>
                        <div className="flex-1 h-8 bg-white/5 rounded-lg overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${percentage}%` }}
                            transition={{ duration: 0.5, ease: 'easeOut' }}
                            className="h-full bg-gradient-to-r from-violet-500 to-fuchsia-500 rounded-lg flex items-center justify-end pr-2"
                          >
                            <span className="text-xs font-medium text-white">${safeAmount.toFixed(2)}</span>
                          </motion.div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-slate-400 text-center py-8">No data available</p>
              )}
            </div>
          </motion.div>
        )}

        {/* Expense List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <ExpenseList
            expenses={expenses}
            loading={loading}
            onEdit={(exp) => { setEditingExpense(exp); setShowForm(true); setError(null); }}
            onDelete={handleDeleteExpense}
          />
        </motion.div>
      </main>

      {/* Add/Edit Expense Modal */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => { setShowForm(false); setEditingExpense(null); }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="w-full max-w-md bg-slate-800 rounded-2xl p-6 border border-white/10 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">
                  {editingExpense ? 'Edit Expense' : 'Add New Expense'}
                </h2>
                <button
                  onClick={() => { setShowForm(false); setEditingExpense(null); }}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-slate-400" />
                </button>
              </div>
              
              <ExpenseForm
                onSubmit={editingExpense ? handleUpdateExpense : handleAddExpense}
                initialData={editingExpense}
                onCancel={() => { setShowForm(false); setEditingExpense(null); }}
              />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
    </ErrorBoundary>
  );
}

export default App;
